package com.android.fmradio;

import android.util.Log;
import java.util.concurrent.atomic.AtomicInteger;

/** JNI callback target expected by FYT libfmjni.so. */
public final class FmService {
    private static final String TAG = "FytRadioTest/FmService";
    private static final AtomicInteger PI = new AtomicInteger();
    private static final AtomicInteger PTY = new AtomicInteger();
    private static final AtomicInteger AF_RAW = new AtomicInteger();
    private static volatile Listener listener;

    public interface Listener {
        void onRdsEvent(int eventType, int p1, int p2, int p3);
    }

    private FmService() {}

    public static void setListener(Listener value) { listener = value; }

    public static int Rdscallback(int eventType, int p1, int p2, int p3) {
        Log.d(TAG, "Rdscallback type=" + eventType + " p1=" + p1 + " p2=" + p2 + " p3=" + p3);
        if (eventType == 2 || eventType == 7) PTY.set(p1);
        if (eventType == 9) AF_RAW.set(p1);
        if (eventType == 14) PI.set(p1);
        Listener value = listener;
        if (value != null) value.onRdsEvent(eventType, p1, p2, p3);
        return 0;
    }

    public static int Rdscallback(int eventType, String data) {
        Log.d(TAG, "Rdscallback string type=" + eventType + " data=" + data);
        return 0;
    }

    public static int Rdscallback(int eventType, byte[] data) {
        Log.d(TAG, "Rdscallback bytes type=" + eventType + " len=" + (data == null ? 0 : data.length));
        return 0;
    }

    public static int callback(int a, int b) {
        Log.d(TAG, "callback a=" + a + " b=" + b);
        return 0;
    }

    public static int getPi() { return PI.get(); }
    public static int getPty() { return PTY.get(); }
    public static int getAfRaw() { return AF_RAW.get(); }
    public static void clearRds() { PI.set(0); PTY.set(0); AF_RAW.set(0); }
}
