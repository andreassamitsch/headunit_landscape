package com.android.fmradio;

import android.os.Bundle;
import android.util.Log;
import java.nio.charset.Charset;
import java.util.Locale;

/** Exact JNI class/package expected by FYT's system libfmjni.so. */
public final class FmNative {
    private static final String TAG = "FytRadioTest/FmNative";
    public static final int CMD_GET_MONO_STEREO = 9;
    public static final int CMD_GET_RSSI = 11;
    public static final int CMD_SET_AREA = 20;
    public static final int CMD_RDS_ON_OFF = 21;
    public static final int CMD_GET_PS = 30;
    public static final int CMD_GET_TEXT = 31;
    public static final int AREA_EUROPE = 2;
    private static final Charset RDS_CHARSET = Charset.forName("ISO-8859-1");
    private static final boolean LIBRARY_LOADED;

    static {
        boolean loaded;
        try {
            System.loadLibrary("fmjni");
            loaded = true;
            Log.i(TAG, "libfmjni.so loaded");
        } catch (Throwable t) {
            loaded = false;
            Log.e(TAG, "libfmjni.so load failed", t);
        }
        LIBRARY_LOADED = loaded;
    }

    public static boolean isLibraryLoaded() { return LIBRARY_LOADED; }

    public native boolean openDev();
    public native boolean closeDev();
    public native boolean powerUp(float frequency);
    public native boolean powerDown(int type);
    public native boolean tune(float frequency);
    public native float[] seek(float frequency, boolean isUp);
    public native int setMute(boolean mute);
    public static native short[] autoScan(int band);
    public native boolean stopScan();
    public native byte[] getPs();
    public native byte[] getLrText();
    public native int setRds(boolean enable);
    public native short readRds();
    public native int isRdsSupport();
    public native int setmonostero(int mode);
    public native int getmonostero(int mode);
    public native int switchAntenna(int antenna);
    public native short activeAf();
    public native int setconfig(String config);
    public native int sqlautoScan(int band, short[] freqList, short[] rssiList);
    public native int fmsyu_jni(int cmd, Object inData, Object outData);

    public int getRssi() {
        if (!LIBRARY_LOADED) return -1;
        try {
            Bundle out = new Bundle();
            int result = fmsyu_jni(CMD_GET_RSSI, new Bundle(), out);
            if (result == 0) return out.getInt("rssilevel", out.getInt("value", -1));
        } catch (Throwable t) {
            Log.w(TAG, "getRssi failed", t);
        }
        return -1;
    }

    public boolean setEuropeArea() {
        if (!LIBRARY_LOADED) return false;
        try {
            Bundle in = new Bundle();
            in.putInt("area", AREA_EUROPE);
            return fmsyu_jni(CMD_SET_AREA, in, new Bundle()) == 0;
        } catch (Throwable t) {
            Log.w(TAG, "setEuropeArea failed", t);
            return false;
        }
    }

    public String getPsString() {
        byte[] bytes = null;
        try {
            Bundle out = new Bundle();
            if (fmsyu_jni(CMD_GET_PS, new Bundle(), out) == 0) bytes = out.getByteArray("PSname");
        } catch (Throwable ignored) {}
        if (bytes == null || bytes.length == 0) {
            try { bytes = getPs(); } catch (Throwable ignored) {}
        }
        return decode(bytes);
    }

    public String getRadioText() {
        byte[] bytes = null;
        try {
            Bundle out = new Bundle();
            if (fmsyu_jni(CMD_GET_TEXT, new Bundle(), out) == 0) bytes = out.getByteArray("Text");
        } catch (Throwable ignored) {}
        if (bytes == null || bytes.length == 0) {
            try { bytes = getLrText(); } catch (Throwable ignored) {}
        }
        return decode(bytes);
    }

    public boolean isStereo() {
        try {
            Bundle out = new Bundle();
            if (fmsyu_jni(CMD_GET_MONO_STEREO, new Bundle(), out) == 0) {
                return out.getInt("status", 0) == 1;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private static String decode(byte[] bytes) {
        if (bytes == null || bytes.length == 0) return "";
        String value = new String(bytes, RDS_CHARSET)
                .replaceAll("[\\x00-\\x1F]", "")
                .trim();
        if (value.toLowerCase(Locale.ROOT).contains("not support")) return "";
        return value;
    }
}
