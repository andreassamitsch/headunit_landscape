package com.metrolist.fytradiotest;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/** Reflection bridge for FYT's android.tw.john.TWUtil MCU API. */
final class TWUtilHelper {
    static final int CMD_RADIO_POWER = 0x101;
    static final int CMD_RADIO_FREQ = 0x102;
    static final int CMD_RADIO_SEEK = 0x103;
    static final int CMD_RADIO_BAND = 0x104;
    static final int CMD_RADIO_MUTE = 0x105;
    static final int CMD_AUDIO_SOURCE = 0x110;
    static final int CMD_RADIO_AREA = 0x112;
    static final int AUDIO_SOURCE_FM = 0x01;

    interface Logger { void log(String line); }

    private final Logger logger;
    private Class<?> clazz;
    private Object instance;
    private boolean available;
    private boolean opened;
    private final Handler mcuHandler = new Handler(Looper.getMainLooper()) {
        @Override public void handleMessage(Message msg) {
            logger.log("TWUtil event what=" + msg.what + " arg1=" + msg.arg1 + " arg2=" + msg.arg2);
        }
    };

    TWUtilHelper(Logger logger) {
        this.logger = logger;
        try {
            clazz = Class.forName("android.tw.john.TWUtil");
            available = true;
            logger.log("TWUtil class available");
        } catch (Throwable t) {
            available = false;
            logger.log("TWUtil unavailable: " + t);
        }
    }

    boolean isAvailable() { return available; }

    synchronized boolean open() {
        if (opened && instance != null) return true;
        if (!available) return false;
        try {
            Constructor<?> constructor = clazz.getConstructor(int.class);
            instance = constructor.newInstance(1);
            short[] commands = new short[] {
                    0x101, 0x102, 0x103, 0x104, 0x105, 0x106,
                    0x110, 0x111, 0x112, 0x113, 0x114, 0x115
            };
            Method open = clazz.getMethod("open", short[].class);
            int result = (Integer) open.invoke(instance, (Object) commands);
            logger.log("TWUtil.open=" + result);
            if (result != 0) return false;
            clazz.getMethod("start").invoke(instance);
            clazz.getMethod("addHandler", String.class, Handler.class).invoke(instance, "radio", mcuHandler);
            opened = true;
            return true;
        } catch (Throwable t) {
            logger.log("TWUtil open failed: " + t);
            return false;
        }
    }

    synchronized void close() {
        if (instance == null) return;
        try { clazz.getMethod("stop").invoke(instance); } catch (Throwable ignored) {}
        try { clazz.getMethod("close").invoke(instance); } catch (Throwable ignored) {}
        instance = null;
        opened = false;
    }

    int write(int command, int value) {
        if (instance == null) return -1;
        try {
            return (Integer) clazz.getMethod("write", int.class, int.class).invoke(instance, command, value);
        } catch (Throwable t) {
            logger.log("TWUtil write(" + command + "," + value + ") failed: " + t);
            return -1;
        }
    }

    int write(int command, int value1, int value2) {
        if (instance == null) return -1;
        try {
            return (Integer) clazz.getMethod("write", int.class, int.class, int.class)
                    .invoke(instance, command, value1, value2);
        } catch (Throwable t) {
            logger.log("TWUtil write3 failed: " + t);
            return -1;
        }
    }

    void initRadioSequence() {
        write(CMD_RADIO_POWER, 0xFF);
        write(CMD_RADIO_FREQ, 0xFF);
        write(CMD_RADIO_FREQ, 0xFF, 1);
        write(CMD_RADIO_AREA, 0xFF);
        write(CMD_RADIO_FREQ, 0xFF, 0);
        write(CMD_RADIO_BAND, 0xFF);
        write(CMD_RADIO_SEEK, 0);
        write(CMD_RADIO_MUTE, 0xFF);
        write(CMD_RADIO_POWER, 0xFF);
        write(CMD_AUDIO_SOURCE, 0xFF);
        logger.log("TWUtil init sequence sent");
    }

    void radioOnFm() {
        logger.log("TWUtil radio power=" + write(CMD_RADIO_POWER, 1));
        setAudioSourceFm();
    }

    void setAudioSourceFm() {
        logger.log("TWUtil source FM=" + write(CMD_AUDIO_SOURCE, AUDIO_SOURCE_FM));
    }

    void unmute() { logger.log("TWUtil unmute=" + write(CMD_RADIO_MUTE, 0)); }
    void mute() { logger.log("TWUtil mute=" + write(CMD_RADIO_MUTE, 1)); }
    void radioOff() { logger.log("TWUtil radio off=" + write(CMD_RADIO_POWER, 0)); }
}
