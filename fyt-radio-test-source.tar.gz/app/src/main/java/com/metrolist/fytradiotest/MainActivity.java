package com.metrolist.fytradiotest;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.android.fmradio.FmNative;
import com.android.fmradio.FmService;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity implements SyuToolkitBridge.Listener {
    private static final float FM_MIN = 87.5f;
    private static final float FM_MAX = 108.0f;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private HandlerThread workerThread;
    private Handler worker;
    private FmNative fm;
    private TWUtilHelper tw;
    private FytAudioRouter router;
    private SyuToolkitBridge syu;
    private TextView frequencyView;
    private TextView statusView;
    private TextView psView;
    private TextView rtView;
    private TextView signalView;
    private TextView propertiesView;
    private TextView logView;
    private ScrollView logScroll;
    private EditText frequencyInput;
    private final AtomicBoolean radioOn = new AtomicBoolean(false);
    private final AtomicBoolean polling = new AtomicBoolean(false);
    private volatile float frequency = 98.5f;
    private volatile boolean muted;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        workerThread = new HandlerThread("FytRadioWorker");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        buildUi();

        fm = new FmNative();
        tw = new TWUtilHelper(this::log);
        router = new FytAudioRouter(this, this::log);
        syu = new SyuToolkitBridge(this, this);
        FmService.setListener((type, p1, p2, p3) -> log("RDS event " + type + ": " + p1 + "," + p2 + "," + p3));

        log("FYT Radio Test 0.1.0 gestartet");
        log("libfmjni loaded=" + FmNative.isLibraryLoaded());
        worker.post(() -> log("TWUtil open=" + tw.open()));
        syu.connect();
        updateProperties();
        updateStatus("Bereit – NavRadio+/Originalradio vorher beenden");
    }

    private void buildUi() {
        int pad = dp(12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(Color.rgb(17, 19, 24));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(0, 0, pad, 0);
        root.addView(controls, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1.05f));

        TextView title = text("FYT / DUDU7 Radio-Test", 24, true);
        controls.addView(title);
        statusView = text("", 15, false); controls.addView(statusView);
        frequencyView = text("98,5 MHz", 42, true); frequencyView.setGravity(Gravity.CENTER_HORIZONTAL); controls.addView(frequencyView);
        psView = text("PS: –", 22, true); controls.addView(psView);
        rtView = text("RT: –", 16, false); controls.addView(rtView);
        signalView = text("RSSI: – | Stereo: – | PI: – | PTY: –", 14, false); controls.addView(signalView);

        LinearLayout inputRow = row();
        frequencyInput = new EditText(this);
        frequencyInput.setText("98.5");
        frequencyInput.setTextColor(Color.WHITE);
        frequencyInput.setHintTextColor(Color.GRAY);
        frequencyInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        inputRow.addView(frequencyInput, new LinearLayout.LayoutParams(0, dp(52), 1f));
        inputRow.addView(button("TUNE", v -> tuneFromInput()), new LinearLayout.LayoutParams(dp(120), dp(52)));
        controls.addView(inputRow);

        LinearLayout power = row();
        power.addView(button("RADIO EIN", v -> powerOn()), weightButton());
        power.addView(button("RADIO AUS", v -> powerOff()), weightButton());
        power.addView(button("MUTE", v -> toggleMute()), weightButton());
        controls.addView(power);

        LinearLayout tune = row();
        tune.addView(button("SEEK ◀", v -> seek(false)), weightButton());
        tune.addView(button("− 0,1", v -> step(-0.1f)), weightButton());
        tune.addView(button("+ 0,1", v -> step(0.1f)), weightButton());
        tune.addView(button("SEEK ▶", v -> seek(true)), weightButton());
        controls.addView(tune);

        LinearLayout tools = row();
        tools.addView(button("AUDIO FM", v -> worker.post(() -> { router.prepare(); syu.claimRadioSource(); tw.setAudioSourceFm(); })), weightButton());
        tools.addView(button("RDS EIN", v -> worker.post(() -> {
            try { log("setRds(true)=" + fm.setRds(true)); }
            catch (Throwable t) { log("setRds FEHLER: " + t); }
        })), weightButton());
        tools.addView(button("STATUS", v -> worker.post(this::pollOnce)), weightButton());
        tools.addView(button("LOG LEEREN", v -> ui.post(() -> logView.setText(""))), weightButton());
        controls.addView(tools);

        propertiesView = text("", 12, false);
        controls.addView(propertiesView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        root.addView(right, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 0.95f));
        right.addView(text("Ereignisprotokoll", 18, true));
        logView = text("", 12, false);
        logView.setTextIsSelectable(true);
        logScroll = new ScrollView(this);
        logScroll.addView(logView);
        right.addView(logScroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private void powerOn() {
        worker.post(() -> {
            if (!FmNative.isLibraryLoaded()) { log("ABBRUCH: libfmjni.so nicht geladen"); return; }
            updateStatus("Initialisiere FYT-Radio …");
            try {
                router.prepare();
                syu.claimRadioSource();
                if (tw.isAvailable() && !tw.open()) log("WARNUNG: TWUtil konnte nicht geöffnet werden");
                tw.initRadioSequence();
                sleep(150);
                tw.radioOnFm();
                sleep(100);
                tw.unmute();
                sleep(50);

                boolean opened = fm.openDev();
                log("openDev=" + opened);
                boolean powered = fm.powerUp(frequency);
                log("powerUp(" + frequency + ")=" + powered);
                boolean tuned = fm.tune(frequency);
                log("tune(" + frequency + ")=" + tuned);
                int muteResult = fm.setMute(false);
                log("setMute(false)=" + muteResult);
                fm.setEuropeArea();
                int rds = fm.setRds(true);
                log("setRds(true)=" + rds);
                for (int i = 0; i < 3; i++) { tw.setAudioSourceFm(); sleep(100); }
                radioOn.set(opened && powered);
                muted = false;
                FmService.clearRds();
                updateStatus(radioOn.get() ? "Radio aktiv" : "Start fehlgeschlagen – Log prüfen");
                if (radioOn.get()) startPolling();
            } catch (Throwable t) {
                radioOn.set(false);
                log("POWER ON FEHLER: " + t);
                updateStatus("Fehler beim Start");
            }
        });
    }

    private void powerOff() {
        worker.post(() -> {
            polling.set(false);
            try { fm.setMute(true); } catch (Throwable ignored) {}
            try { fm.powerDown(0); } catch (Throwable t) { log("powerDown: " + t); }
            try { fm.closeDev(); } catch (Throwable t) { log("closeDev: " + t); }
            try { tw.radioOff(); } catch (Throwable ignored) {}
            syu.releaseRadioSource();
            router.release();
            radioOn.set(false);
            updateStatus("Radio aus");
            log("Radio ausgeschaltet und Audio-Mux freigegeben");
        });
    }

    private void tuneFromInput() {
        String text = frequencyInput.getText().toString().trim().replace(',', '.');
        try { tune(Float.parseFloat(text)); }
        catch (NumberFormatException e) { log("Ungültige Frequenz: " + text); }
    }

    private void step(float delta) { tune(Math.round((frequency + delta) * 10f) / 10f); }

    private void tune(float value) {
        final float target = Math.max(FM_MIN, Math.min(FM_MAX, value));
        frequency = target;
        updateFrequency();
        worker.post(() -> {
            try {
                FmService.clearRds();
                boolean result = fm.tune(target);
                log("tune(" + target + ")=" + result);
            } catch (Throwable t) { log("tune FEHLER: " + t); }
        });
    }

    private void seek(boolean up) {
        worker.post(() -> {
            try {
                log("seek(" + frequency + ", up=" + up + ") …");
                float[] result = fm.seek(frequency, up);
                log("seek result=" + java.util.Arrays.toString(result));
                if (result != null && result.length > 0 && result[0] >= FM_MIN && result[0] <= FM_MAX) {
                    frequency = result[0];
                    FmService.clearRds();
                    updateFrequency();
                }
            } catch (Throwable t) { log("seek FEHLER: " + t); }
        });
    }

    private void toggleMute() {
        worker.post(() -> {
            muted = !muted;
            try {
                int result = fm.setMute(muted);
                if (muted) tw.mute(); else tw.unmute();
                log("mute=" + muted + " result=" + result);
            } catch (Throwable t) { log("mute FEHLER: " + t); }
        });
    }

    private void startPolling() {
        if (!polling.compareAndSet(false, true)) return;
        worker.post(new Runnable() {
            @Override public void run() {
                if (!polling.get()) return;
                pollOnce();
                worker.postDelayed(this, 1000);
            }
        });
    }

    private void pollOnce() {
        try { fm.readRds(); } catch (Throwable ignored) {}
        String ps = safeString(fm::getPsString);
        String rt = safeString(fm::getRadioText);
        int rssi = safeInt(fm::getRssi, -1);
        boolean stereo = safeBool(fm::isStereo, false);
        int pi = FmService.getPi();
        int pty = FmService.getPty();
        ui.post(() -> {
            psView.setText("PS: " + (ps.isEmpty() ? "–" : ps));
            rtView.setText("RT: " + (rt.isEmpty() ? "–" : rt));
            signalView.setText("RSSI: " + rssi + " | Stereo: " + (stereo ? "ja" : "nein")
                    + " | PI: " + (pi == 0 ? "–" : String.format(Locale.ROOT, "%04X", pi & 0xffff))
                    + " | PTY: " + (pty == 0 ? "–" : pty));
        });
    }

    private void updateProperties() {
        String[] keys = {
                "ro.board.platform", "ro.product.board", "sys.fyt.radio_type", "ro.hw.radio.chip",
                "persist.fyt.fm.default", "persist.fyt.fm.rdsstate", "ro.fyt.fmsens", "ro.fyt.amsens"
        };
        StringBuilder out = new StringBuilder("Gerätewerte\n");
        for (String key : keys) out.append(key).append(" = ").append(SystemPropertiesReader.get(key)).append('\n');
        propertiesView.setText(out.toString());
    }

    private void updateFrequency() {
        ui.post(() -> {
            frequencyView.setText(String.format(Locale.GERMANY, "%.1f MHz", frequency));
            frequencyInput.setText(String.format(Locale.US, "%.1f", frequency));
        });
    }

    private void updateStatus(String text) { ui.post(() -> statusView.setText("Status: " + text)); }

    @Override public void log(String line) {
        String timestamp = new SimpleDateFormat("HH:mm:ss.SSS", Locale.ROOT).format(new Date());
        ui.post(() -> {
            logView.append(timestamp + "  " + line + "\n");
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    @Override public void onFrequencyCallback(int rawValue) {
        if (rawValue >= 8700 && rawValue <= 10900) {
            frequency = rawValue / 100f;
            updateFrequency();
        }
    }

    @Override protected void onDestroy() {
        polling.set(false);
        if (radioOn.get()) {
            try { fm.setMute(true); } catch (Throwable ignored) {}
            try { fm.powerDown(0); } catch (Throwable ignored) {}
            try { fm.closeDev(); } catch (Throwable ignored) {}
            try { tw.radioOff(); } catch (Throwable ignored) {}
            try { syu.releaseRadioSource(); } catch (Throwable ignored) {}
            try { router.release(); } catch (Throwable ignored) {}
            radioOn.set(false);
        }
        if (syu != null) syu.close();
        if (tw != null) tw.close();
        if (workerThread != null) workerThread.quitSafely();
        FmService.setListener(null);
        super.onDestroy();
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(Color.WHITE);
        view.setTextSize(sp);
        view.setPadding(dp(4), dp(4), dp(4), dp(4));
        if (bold) view.setTypeface(null, android.graphics.Typeface.BOLD);
        return view;
    }

    private Button button(String label, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setOnClickListener(listener);
        return button;
    }

    private LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(4), 0, dp(4));
        return row;
    }

    private LinearLayout.LayoutParams weightButton() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(52), 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    private interface BoolCall { boolean run() throws Throwable; }
    private interface IntCall { int run() throws Throwable; }
    private interface StringCall { String run() throws Throwable; }
    private void safe(String label, BoolCall call) { try { log(label + "=" + call.run()); } catch (Throwable t) { log(label + " FEHLER: " + t); } }
    private int safeInt(IntCall call, int fallback) { try { return call.run(); } catch (Throwable t) { return fallback; } }
    private boolean safeBool(BoolCall call, boolean fallback) { try { return call.run(); } catch (Throwable t) { return fallback; } }
    private String safeString(StringCall call) { try { String s = call.run(); return s == null ? "" : s; } catch (Throwable t) { return ""; } }
}
