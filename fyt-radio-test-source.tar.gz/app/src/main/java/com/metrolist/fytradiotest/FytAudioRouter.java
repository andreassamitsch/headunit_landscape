package com.metrolist.fytradiotest;

import android.content.Context;
import android.content.Intent;

/** Best-effort FYT audio mux routing via exported system services. */
final class FytAudioRouter {
    interface Logger { void log(String line); }
    private final Context context;
    private final Logger logger;

    FytAudioRouter(Context context, Logger logger) {
        this.context = context.getApplicationContext();
        this.logger = logger;
    }

    void prepare() {
        startAction("com.syu.music.switch_fm", "com.syu.music");
        startAction("com.android.fmradio.IFmRadioService", "com.syu.ms");
        try {
            Intent intent = new Intent();
            intent.setClassName("com.syu.ms", "com.android.fmradio.FmService");
            logger.log("start com.syu.ms FmService -> " + context.startService(intent));
        } catch (Throwable t) {
            logger.log("start FmService component failed: " + t);
        }
        try {
            context.sendBroadcast(new Intent("com.action.ACTION_OPEN_RADIO"));
            logger.log("ACTION_OPEN_RADIO sent");
        } catch (Throwable t) {
            logger.log("ACTION_OPEN_RADIO failed: " + t);
        }
    }

    void release() {
        startAction("com.syu.music.switch_none", "com.syu.music");
    }

    private void startAction(String action, String packageName) {
        try {
            Intent intent = new Intent(action).setPackage(packageName);
            logger.log("start " + action + " -> " + context.startService(intent));
        } catch (Throwable t) {
            logger.log("start " + action + " failed: " + t);
        }
    }
}
