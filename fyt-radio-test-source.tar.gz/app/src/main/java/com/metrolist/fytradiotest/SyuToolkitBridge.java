package com.metrolist.fytradiotest;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import com.syu.ipc.IModuleCallback;
import com.syu.ipc.IRemoteModule;
import com.syu.ipc.IRemoteToolkit;
import java.util.Arrays;

/** Direct Binder bridge to com.syu.ms/app.ToolkitService. */
final class SyuToolkitBridge {
    interface Listener {
        void log(String line);
        void onFrequencyCallback(int rawValue);
    }

    private static final int MODULE_MAIN = 0;
    private static final int MODULE_RADIO = 1;
    private static final int CMD_APP_ID = 0;
    private static final int APP_ID_CAR_RADIO = 0x0b;

    private final Context context;
    private final Listener listener;
    private final HandlerThread thread = new HandlerThread("SyuToolkit");
    private final Handler handler;
    private IRemoteToolkit toolkit;
    private IRemoteModule mainModule;
    private IRemoteModule radioModule;
    private boolean bound;

    SyuToolkitBridge(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        thread.start();
        handler = new Handler(thread.getLooper());
    }

    private final IModuleCallback callback = new IModuleCallback.Stub() {
        @Override public void update(int type, int[] ints, float[] floats, String[] strings) {
            listener.log("SYU callback type=" + type + " ints=" + Arrays.toString(ints)
                    + " floats=" + Arrays.toString(floats) + " strings=" + Arrays.toString(strings));
            if (type == 1 && ints != null && ints.length > 0) listener.onFrequencyCallback(ints[0]);
        }
    };

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder service) {
            handler.post(() -> {
                try {
                    toolkit = IRemoteToolkit.Stub.asInterface(service);
                    mainModule = toolkit.getRemoteModule(MODULE_MAIN);
                    radioModule = toolkit.getRemoteModule(MODULE_RADIO);
                    listener.log("SYU connected: main=" + (mainModule != null) + " radio=" + (radioModule != null));
                    if (radioModule != null) {
                        int ok = 0;
                        for (int event = 0; event < 100; event++) {
                            try { radioModule.register(callback, event, 1); ok++; } catch (Throwable ignored) {}
                        }
                        listener.log("SYU callbacks registered: " + ok + "/100");
                    }
                } catch (Throwable t) {
                    listener.log("SYU init failed: " + t);
                }
            });
        }

        @Override public void onServiceDisconnected(ComponentName name) {
            toolkit = null; mainModule = null; radioModule = null;
            listener.log("SYU disconnected");
        }
    };

    void connect() {
        try {
            Intent intent = new Intent();
            intent.setClassName("com.syu.ms", "app.ToolkitService");
            bound = context.bindService(intent, connection, Context.BIND_AUTO_CREATE);
            listener.log("bind com.syu.ms/app.ToolkitService=" + bound);
        } catch (Throwable t) {
            listener.log("SYU bind failed: " + t);
        }
    }

    void claimRadioSource() {
        sendAppId(APP_ID_CAR_RADIO);
        handler.postDelayed(() -> sendAppId(APP_ID_CAR_RADIO), 300);
        handler.postDelayed(() -> sendAppId(APP_ID_CAR_RADIO), 1000);
    }

    void releaseRadioSource() { sendAppId(0); }

    private void sendAppId(int value) {
        handler.post(() -> {
            try {
                if (mainModule == null) {
                    listener.log("SYU APP_ID pending; main module not ready");
                    return;
                }
                mainModule.call(CMD_APP_ID, new int[]{value}, null, null);
                listener.log("SYU APP_ID=" + value + " sent");
            } catch (Throwable t) {
                listener.log("SYU APP_ID failed: " + t);
            }
        });
    }

    void close() {
        handler.post(() -> {
            if (radioModule != null) {
                for (int event = 0; event < 100; event++) {
                    try { radioModule.unregister(callback, event); } catch (Throwable ignored) {}
                }
            }
        });
        if (bound) {
            try { context.unbindService(connection); } catch (Throwable ignored) {}
        }
        thread.quitSafely();
    }
}
