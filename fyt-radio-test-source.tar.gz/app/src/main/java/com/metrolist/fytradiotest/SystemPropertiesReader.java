package com.metrolist.fytradiotest;

import java.lang.reflect.Method;

final class SystemPropertiesReader {
    private SystemPropertiesReader() {}

    static String get(String key) {
        try {
            Class<?> cls = Class.forName("android.os.SystemProperties");
            Method method = cls.getMethod("get", String.class, String.class);
            return (String) method.invoke(null, key, "<leer>");
        } catch (Throwable t) {
            return "<nicht lesbar: " + t.getClass().getSimpleName() + ">";
        }
    }
}
