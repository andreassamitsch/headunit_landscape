package com.syu.ipc;

import android.os.Parcel;
import android.os.Parcelable;

public final class ModuleObject implements Parcelable {
    public int[] intData;
    public float[] floatData;
    public String[] stringData;

    public ModuleObject() {}

    private ModuleObject(Parcel in) {
        intData = in.createIntArray();
        floatData = in.createFloatArray();
        stringData = in.createStringArray();
    }

    @Override public void writeToParcel(Parcel dest, int flags) {
        dest.writeIntArray(intData);
        dest.writeFloatArray(floatData);
        dest.writeStringArray(stringData);
    }

    @Override public int describeContents() { return 0; }

    public static final Creator<ModuleObject> CREATOR = new Creator<ModuleObject>() {
        @Override public ModuleObject createFromParcel(Parcel in) { return new ModuleObject(in); }
        @Override public ModuleObject[] newArray(int size) { return new ModuleObject[size]; }
    };
}
